#
# common code given to the students
# only edit the source, this gets copied into distribution
#