plotting potter
uses only harryPotter.txt

BUT it mounts the notebook in finding characters
which uses huck.txt

harryPotter.txt:

Cleaning that could still be done:
  * remove page numbers in it
  * normalize whitespace between chapter headings, titles and text

After updates copy this file to Google Drive !
